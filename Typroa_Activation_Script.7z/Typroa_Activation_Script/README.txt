注：该脚本编译自开源项目（https://github.com/DiamondHunters/NodeInject_Hook_example）

1. 把解压出来的两个 exe 文件复制到 Typora 的安装目录下。

2. 以管理员身份运行 CMD。

3. 输入“cd 安装路径”，按回车，跳转到 Typora 再重新激活的。安装路径。

4. 先输入 node_inject.exe 按回车，等待提示"done!"。

5. 再输入 license-gen.exe 按回车，等待显示序列号。

6. 打开 Typora 并输入序列号激活。

7. 更新后可能导致无法激活，需要先彻底卸载 Typora 再重新激活。